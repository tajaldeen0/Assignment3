/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lapnotpad;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.FilterWriter;
import java.io.IOException;
import java.io.InputStream;
import java.util.Optional;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.DialogEvent;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.TextInputDialog;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.*;
import javafx.scene.layout.*;
import javafx.scene.text.Font;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

/**
 *
 * @author taj
 */
public class LapNotPad extends Application {

    static int countOccurences(String str, String word) {
        
       
        /*
        String[] a = befor.split(" ");
        int count = 0;
        for (int i = 0; i < a.length; i++) {

            if (word.equals(a[i])) {
                count++;
            }
        }

        return count;
        */
        Pattern pattern = Pattern.compile(word);
    Matcher  matcher = pattern.matcher(str);

    int count = 0;
    while (matcher.find())
        count++;

    return count; 
    }

    File file = new File("");
    FileChooser fc = new FileChooser();
    JFrame j;

    @Override
    public void start(Stage primaryStage) {

        TextArea textArea = new TextArea();
        textArea.setPrefSize(primaryStage.getWidth(), primaryStage.getMaxHeight());
        MenuBar menuBar = new MenuBar();

        Menu fileMenu = new Menu("File");
        Menu EditMenu = new Menu("Edit");
        Menu FormatMenu = new Menu("Format");
        Menu ColorMenu = new Menu("Color");

        MenuItem newFile = new MenuItem("New");
        MenuItem newWindow = new MenuItem("New Widow");
        MenuItem open = new MenuItem("Open");
        MenuItem save = new MenuItem("Save");
        MenuItem saveAs = new MenuItem("Save As");
        MenuItem exit = new MenuItem("Exit");

        /**
         * 
         */
        MenuItem Serch = new MenuItem("Search");

        Serch.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {

                TextInputDialog dialog = new TextInputDialog("");
                dialog.setTitle("search for numper word");

                dialog.getDialogPane().setContentText("Find what");
                Optional<String> reusalt=dialog.showAndWait();
                TextField tf = dialog.getEditor();
                if (tf.getText() != null && tf.getText().length() != 0) {
                  
                    System.out.println("Counter : " +countOccurences(textArea.getText().toString(), tf.getText()));

                } else {
                    System.out.println("you not entered anything");
                }

                //dialog.show();

            }

        });

        /**
         * 
         */
        /**
         * 
         */
        Menu zoom = new Menu("Zoom");
        MenuItem zoomin = new MenuItem("Zoom In");
        MenuItem zoomout = new MenuItem("Zoom Out");
        MenuItem zoomDefault = new MenuItem("Restore Default Zoom");

        zoom.getItems().addAll(zoomin, zoomout, zoomDefault);

        FormatMenu.getItems().add(zoom);

        //**//
        zoomin.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                Font font = textArea.getFont();
                float size = (float) font.getSize() + 1.0f;
                textArea.setFont(new Font(size));
            }
        });
        zoomout.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                Font font = textArea.getFont();
                float size = (float) font.getSize() - 1.0f;
                textArea.setFont(new Font(size));
            }
        });

        zoomDefault.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                textArea.setFont(new Font(16));
            }
        });

        /**
         * 
         */
        fileMenu.getItems().addAll(newFile, newWindow, open, save, saveAs, exit);
        EditMenu.getItems().add(Serch);
        menuBar.getMenus().addAll(fileMenu, EditMenu, FormatMenu, ColorMenu);

        newFile.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {

                file = new File("");

                textArea.setText("");
                primaryStage.setTitle("Untitled - Notepade");
            }
        });

        newWindow.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                LapNotPad note = new LapNotPad();
                note.start(new Stage());
            }
        });

        open.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                fc.getExtensionFilters().add(new FileChooser.ExtensionFilter("textFile", "*.txt"));

                if (file != null) {
                    file = fc.showOpenDialog(primaryStage);
                    primaryStage.setTitle(file.getName() + " - Notepade");

                } else {
                    JOptionPane.showMessageDialog(j, "the user cancelled the operation");
                }

                try {
                    BufferedReader br = new BufferedReader(new FileReader(file));
                    textArea.setText("");
                    String line = null;
                    while ((line = br.readLine()) != null) {

                        textArea.appendText(line + "\n");// بكمل ع النص تكميل

                    }
                } catch (FileNotFoundException ex) {
                    JOptionPane.showMessageDialog(new JFrame(), ex);
                } catch (IOException ex) {
                    Logger.getLogger(LapNotPad.class.getName()).log(Level.SEVERE, null, ex);
                }

            }
        });
        saveAs.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                fc.getExtensionFilters().add(new FileChooser.ExtensionFilter("text File", "*.text"));
                file = fc.showSaveDialog(primaryStage);
                try {
                    FileWriter fw = new FileWriter(file);
                    fw.write(textArea.getText());
                    primaryStage.setTitle(file.getName() + "- Notepade");
                    fw.close();
                } catch (IOException ex) {
                    Logger.getLogger(LapNotPad.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });

        save.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                if (!file.getName().equals("")) {
                    try {
                        FileWriter fw = new FileWriter(file);
                        fw.write(textArea.getText());
                        fw.close();
                    } catch (IOException ex) {
                        Logger.getLogger(LapNotPad.class.getName()).log(Level.SEVERE, null, ex);
                    }
                } else {
                    saveAs.getOnAction().handle(event);
                }
            }
        });
        exit.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                primaryStage.close();
            }
        });
        BorderPane root = new BorderPane();
        root.setTop(menuBar);
        root.setCenter(textArea);

        Scene scene = new Scene(root, 900, 500);

        primaryStage.setTitle("Untitled - Notepade");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }

}
